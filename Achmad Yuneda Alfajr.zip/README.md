# React JS Notes
Notes berbasis website yang dibuat menggunakan styled components dan react redux toolkit. Situs web ini berguna untuk menambahkan dan menghapus catatan.

# Demo:
https://yuneda.github.io/React-JS-Notes-Website

# Tools:
1. Styled Components
2. React Redux Toolkit

# Fitur:
1. Menambah dan menghapus catatan 
2. Pencarian berdasarkan judul
3. Kategori catatan, yaitu notes dan archive

## Desktop View
![Alt-Text](/src/images/ss-1.jpg)
## Mobile View
![Alt-Text](/src/images/ss-2.jpg)
![Alt-Text](/src/images/ss-3.jpg)